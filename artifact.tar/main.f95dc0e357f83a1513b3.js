/*! For license information please see main.f95dc0e357f83a1513b3.js.LICENSE.txt */
(()=>{"use strict";!function(e,t){let n={};for(let t in e)n[t]=123}({name:"cf",age:29})})();